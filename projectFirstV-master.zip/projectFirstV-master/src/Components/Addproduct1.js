import './Seller/Addproduct.css'
import React from "react";
import {auth,database,newref,storage1} from './firebaseSeller'
import { useHistory } from "react-router";
import {onAuthStateChanged} from 'firebase/auth';
import { ref,uploadBytes,getDownloadURL } from "firebase/storage";
import {push} from "firebase/database"


export default function Addproduct1() {
 
 const history=useHistory()
 const [currentCategory, setCurrentCategory] = React.useState('Electronics')
  const [currentUser,setCurrentUser]=React.useState('')
  
 // to check whether user is logged in or not
 onAuthStateChanged(auth,(user)=>{
if(user)
{
  setCurrentUser(user)
 console.log(currentUser.uid);
  
}
else{
  
  setCurrentUser(null)
 alert("please Login first")
 history.push('/LoginSeller')
}
 })
 
// for assigining the selected category to current category
  const changeCategory = (newCategory) => {
    setCurrentCategory(newCategory)
    const y=newCategory
    console.log(y)
       }
       
    const onSubmit = async(e) => {
     e.preventDefault();
    const productName=e.target.productName.value;
   const Description=e.target.Description.value;
   const cost=e.target.cost.value;
   const file = e.target.File.files[0];
    console.log(file)
    //initializing storage from firebase seller(storage1)
    const storageRef = ref(storage1, file.name);
   //uploading the image file
   uploadBytes(storageRef, file).then((snapshot) => {
    console.log('Uploaded a blob or file!');
    alert("product successfully uploaded....Please check your product in Your Products section ")
    console.log(snapshot)
    
    getDownloadURL(ref(storage1, file.name)).then(d=>{
      console.log(d)
    //pushing the data to real time database with name products  
   push(newref(database, 'products/'), {
        productname: productName,
        description: Description,
        price:cost,
        imageUrl: d,
        Category:currentCategory,
        userId : currentUser.uid,
        productId:currentUser.uid+new Date()
        
        
      });
      
    })
    })
}
 return (
      <>
    <div className="login-form">
                <div>
          
        </div>
       
            <h1>Become an
         <br/>Amazon seller</h1>
         <form onSubmit={onSubmit}>
        <div className="container-form">
         
         <h3><label >ProductName </label></h3>
        <input id="post" className="ProductName-f" name="productName" type='text' required/>
        <br/>
       <h3>  <label >ProductImage </label> </h3>
        <input type="file" name="File" id="image"className="image-upload-f" accept=".jpg,.png,jpeg" required />
        <br/>
     <h3>  <label> Description </label></h3>
        <input  className="Description-f"type="text" name="Description" required/>
        <br></br>
        <h3><label>Category</label></h3> 
        <select className="category"
        onChange={(event) => changeCategory(event.target.value)}
        value={currentCategory} >
        <option value="Electronics">Electronics</option>
        <option value="Home">Home appliances</option>
        <option value="Fashion">clothing and Fashion</option>
        <option value="Kids">Kids</option>

      </select>
<br></br>
      <h3><label>  Price </label></h3>
                  <input className="Price-f" type="text" name="cost" required/>
                  <button className="upload_button-f" type="submit"  >Upload</button>
         </div>
        </form>
        </div>
         
      
    </>
  );
}

 