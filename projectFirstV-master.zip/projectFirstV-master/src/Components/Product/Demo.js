import React from "react";

function Demo() {
  return (
    <div>
      <div className="row">
        <div className="col-1">
          desc: "THIS IS DESCRIPTION FOR PRODUCT-3, consectetur adipiscing elit.
          Done cvenenatis, dolor in finibus malesuada, lectus ipsum porta nunc,
          atiaculis arcu nisi sed mauris. Nulla fermentum vestibulum ex,
          egettristique tortor pretium ut. Curabitur elit justo, consequat id
          condimentum ac, volutpat ornare",
        </div>
        <div className="col-2">
          desc: "THIS IS DESCRIPTION FOR PRODUCT-3, consectetur adipiscing elit.
          Done cvenenatis, dolor in finibus malesuada, lectus ipsum porta nunc,
          atiaculis arcu nisi sed mauris. Nulla fermentum vestibulum ex,
          egettristique tortor pretium ut. Curabitur elit justo, consequat id
          condimentum ac, volutpat ornare",
        </div>
      </div>
      <button className="btn-primary">submit</button>
    </div>
  );
}

export default Demo;
